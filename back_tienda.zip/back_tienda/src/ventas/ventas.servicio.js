import * as ventasRepositorio from './ventas.repositorio.js';
import * as clientesRepositorio from '../clientes/clientes.repository.js'; // Para validar existencia de cliente

export const obtenerVentas = () => ventasRepositorio.obtenerVentas();

export const obtenerVentaPorId = (id) => ventasRepositorio.obtenerVentaPorId(id);

export const crearVenta = async (datos) => {
    // Regla de negocio: total_venta, fecha_venta y cliente (id_cli_venta) son importantes
    if (!datos.total_venta || isNaN(Number(datos.total_venta)) || Number(datos.total_venta) < 0) {
        throw new Error('El campo total_venta es obligatorio y debe ser positivo');
    }
    if (!datos.fecha_venta) {
        throw new Error('El campo fecha_venta es obligatorio');
    }
    // El cliente puede ser null, pero si no es null, valida que exista
    if (datos.id_cli_venta) {
        const cliente = await clientesRepositorio.obtenerClientePorId(datos.id_cli_venta);
        if (!cliente) {
            throw new Error('El cliente proporcionado no existe');
        }
    }
    return ventasRepositorio.crearVenta(datos);
};

export const actualizarVenta = async (id, datos) => {
    // Valida si existe la venta
    const venta = await ventasRepositorio.obtenerVentaPorId(id);
    if (!venta) return null;
    // Mismas validaciones que crearVenta
    if (!datos.total_venta || isNaN(Number(datos.total_venta)) || Number(datos.total_venta) < 0) {
        throw new Error('El campo total_venta es obligatorio y debe ser positivo');
    }
    if (!datos.fecha_venta) {
        throw new Error('El campo fecha_venta es obligatorio');
    }
    if (datos.id_cli_venta) {
        const cliente = await clientesRepositorio.obtenerClientePorId(datos.id_cli_venta);
        if (!cliente) {
            throw new Error('El cliente proporcionado no existe');
        }
    }
    return ventasRepositorio.actualizarVenta(id, datos);
};

export const eliminarVenta = (id) => ventasRepositorio.eliminarVenta(id);
